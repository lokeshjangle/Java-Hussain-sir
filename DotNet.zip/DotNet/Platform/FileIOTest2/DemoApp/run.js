let emp = {"name": "Jack", "salary": 12000};
console.log(`${emp.name} earns ${emp.salary}`);