namespace DemoApp.Models;

public readonly record struct VisitInfo(string VisitorName, int VisitCount, DateTime LastVisit);
