select ProductNo, Price, Stock from ProductInfo;
select OrderNo, OrderDate, CustomerId, ProductNo, Quantity from OrderDetail;
select Id, CurrentValue, SeedValue from Counters;