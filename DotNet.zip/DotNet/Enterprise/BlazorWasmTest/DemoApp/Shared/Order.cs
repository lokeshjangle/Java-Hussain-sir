namespace DemoApp.Shared;

public class Order
{
    public int Id { get; set; }

    public string OrderDate { get; set; }

    public string CustomerId { get; set; }

    public int ProductNo { get; set; }

    public int Quantity { get; set; }
}
