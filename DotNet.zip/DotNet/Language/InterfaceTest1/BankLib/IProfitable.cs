namespace Banking;

public interface IProfitable
{
    double AddInterest(int months);
}
