namespace Banking;

public interface IFineable
{
    bool Withdraw(double penalty);
}