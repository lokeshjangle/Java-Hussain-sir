namespace Banking;

//a type declated with 'public' keyword is visible to other
//types defined in another assembly/project which references
//the current assembly/project
public class InsufficientFundsException : ApplicationException {}

