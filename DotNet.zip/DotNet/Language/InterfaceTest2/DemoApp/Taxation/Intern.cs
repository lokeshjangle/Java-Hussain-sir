namespace Taxation;

public abstract class Intern : ITaxPayer
{
    public abstract decimal AnnualIncome();
}