namespace Finance;

public class EducationLoan 
{
	[MaxDuration]
	public double Common(double amount, int period)
	{
		return 6;
	}

	//expression bodied method
	public double Scholar(double amount, int period) => 4;
}

