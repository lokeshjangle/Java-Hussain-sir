namespace Finance;

public class CarLoan
{
    public double Luxary(double amount, int _) => amount < 500000 ? 15 : 18;
}
