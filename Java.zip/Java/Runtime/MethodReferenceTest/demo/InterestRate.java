interface InterestRate {
    double forPeriod(int count);
}
