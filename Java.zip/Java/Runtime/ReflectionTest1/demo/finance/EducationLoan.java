package finance;

public class EducationLoan {

	public double common(double amount, int period) {
		return 6;
	}

	public double scholar(double amount, int period) {
		return 4;
	}
}

