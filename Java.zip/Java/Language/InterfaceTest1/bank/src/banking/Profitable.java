package banking;

public interface Profitable {
    double interest(int months);
}
